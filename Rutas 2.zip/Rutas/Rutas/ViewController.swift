//
//  ViewController.swift
//  Rutas
//
//  Created by 2020-1 on 10/9/19.
//  Copyright © 2019 BR12. All rights reserved.
//

import UIKit
import MapKit

struct lugar: Codable{
    var titulo: String
    var subtitulo: String
    var latitud: Float
    var longitud: Float
}

let path = Bundle.main.path(forResource: "Json-Final", ofType: "json")

let jsonData = NSData(contentsOfFile: path!)

let lugares = try! JSONDecoder().decode([lugar].self, from: jsonData! as Data)

class puntosElegidos: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init(title: String, subtitle: String, coordinate: CLLocationCoordinate2D) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
    }
}

class ViewController: UIViewController, MKMapViewDelegate {
    
    var selectedPlacemark: Direccion?
    var rutaPuntos: [Direccion] = []
    
    @IBOutlet weak var mapa: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapa.delegate = self
        mapa.mapType = .standard
        let inicioCU = CLLocation(latitude: 19.325890, longitude: -99.182352)
        let radio: CLLocationDistance = 3000.0
        let region = MKCoordinateRegion(center: inicioCU.coordinate, latitudinalMeters: radio, longitudinalMeters: radio)
        mapa.setRegion(region, animated: true)
        
        for pin in lugares {
            let placemarks = CLLocationCoordinate2D(latitude: CLLocationDegrees(pin.latitud) , longitude: CLLocationDegrees(pin.longitud))
            let annttn = Direccion(title: pin.titulo, subtitle: pin.subtitulo, coordinate: placemarks)
            mapa.addAnnotation(annttn)
        }
        
        func creaRuta(inicio: [MKAnnotation], didSelectView: MKAnnotationView){
            
            let anexo = CLLocationCoordinate2D(latitude: 19.325890, longitude: -99.182352)
            mapa.removeAnnotation(rutaPuntos as! MKAnnotation)
            mapa.addAnnotations(inicio)
            let inicioPlacemark = MKPlacemark(coordinate: anexo)
            let destinoPlacemark = MKPlacemark(coordinate: inicio[1].coordinate)
            
            let directionRequest = MKDirections.Request()
            directionRequest.source = MKMapItem(placemark: inicioPlacemark)
            directionRequest.destination = MKMapItem(placemark: destinoPlacemark)
            directionRequest.transportType = .automobile
            
            let directions = MKDirections(request: directionRequest)
            directions.calculate { (response, error) in
                if let error = error{
                    print(error.localizedDescription)
                    return
                }
                guard let directionResponse = response else{
                    return
                }
                let ruta = directionResponse.routes.first
                self.mapa.addOverlay(ruta!.polyline)
                let rect = ruta?.polyline.boundingMapRect
                self.mapa.setRegion(MKCoordinateRegion(rect!), animated: true)
                self.rutaPuntos.removeAll()
            }
        }
        
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer{
            let linea = MKPolylineRenderer(overlay: overlay)
            linea.strokeColor = .cyan
            linea.lineWidth = 4.0
            return linea
        }

        
        /*let inicioLocation = CLLocationCoordinate2DMake(19.3272501, -99.1825469)
        let destinoLocation = CLLocationCoordinate2DMake(19.3248272, -99.1847808)
        
        let inicioPin = Direccion(title: "", subtitle: "", coordinate: inicioLocation
        let destinoPin = Direccion(title: "", subtitle: "", coordinate: destinoLocation)
        mapa.addAnnotations([inicioPin, destinoPin])*/
        
//Ciclo for para mostrar los 20 placemarks en el mapa
        
        /*let tapHandler = UITapGestureRecognizer()
        tapHandler.numberOfTapsRequired = 1
        tapHandler.delegate = self as! UIGestureRecognizerDelegate
        mapa.addGestureRecognizer(tapHandler)
        mapa.isUserInteractionEnabled = true
        
        func tapHandler(tap: UITapGestureRecognizer){
            
        }
        
        func trazaRuta(){
            
        }
        */
    }
}

